#!/usr/bin/env node
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { z } from 'zod';
import axios from 'axios';

const server = new McpServer({
    name: 'ultrahuman-signal',
    version: '0.3.0'
});

const API_URL = 'https://partner.ultrahuman.com/api/v1/metrics';

// Tool: Get Metrics
server.registerTool(
    'get_metrics',
    {
        description: 'Fetches health metrics from the Ultrahuman API. Uses stored secrets for API key and email if not provided.',
        inputSchema: z.object({
            date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Date must be in YYYY-MM-DD format.'),
            email: z.string().email('A valid email format is required.').optional().describe('Defaults to ULTRAHUMAN_EMAIL secret.'),
            metric: z.string().optional().describe("Specific metric to retrieve (e.g., 'sleep', 'hrv')."),
            raw: z.boolean().optional().default(false).describe('If true, returns the full raw JSON.')
        })
    },
    async (args) => {
        const apiKey = process.env.ULTRAHUMAN_API_KEY;
        const defaultEmail = process.env.ULTRAHUMAN_EMAIL;
        const email = args.email || defaultEmail;

        if (!apiKey) {
            return {
                content: [{ 
                    type: 'text', 
                    text: "❌ API Key missing. Please run 'tars secret set ULTRAHUMAN_API_KEY YOUR_KEY' and restart Tars." 
                }],
                isError: true
            };
        }

        if (!email) {
            return {
                content: [{ 
                    type: 'text', 
                    text: "❌ Email missing. Provide an email or run 'tars secret set ULTRAHUMAN_EMAIL your_email@example.com'." 
                }],
                isError: true
            };
        }

        try {
            const response = await axios.get(API_URL, {
                params: {
                    email: email,
                    date: args.date
                },
                headers: {
                    'Authorization': apiKey
                }
            });

            const data = response.data;

            if (args.raw) {
                return {
                    content: [{ type: 'text', text: JSON.stringify(data, null, 2) }]
                };
            }

            if (args.metric) {
                const metricData = data[args.metric];
                if (!metricData) {
                    return {
                        content: [{ type: 'text', text: `No data found for metric: ${args.metric}` }]
                    };
                }
                return {
                    content: [{ type: 'text', text: JSON.stringify(metricData, null, 2) }]
                };
            }

            // Default Summary View
            const summary = {
                "Metabolic Score": data.metabolic_score,
                "Movement Index": data.movement_index,
                "Recovery Index": data.recovery_index,
                "Avg Glucose": data.avg_glucose,
                "VO2 Max": data.vo2_max,
                "Steps": data.steps
            };

            return {
                content: [{ 
                    type: 'text', 
                    text: `Ultrahuman Metrics Summary for ${email} on ${args.date}:\n` + JSON.stringify(summary, null, 2) 
                }]
            };

        } catch (error) {
            const errorMsg = error.response?.data?.message || error.message;
            return {
                content: [{ type: 'text', text: `❌ API Error: ${errorMsg}` }],
                isError: true
            };
        }
    }
);

async function main() {
    const transport = new StdioServerTransport();
    await server.connect(transport);
}

main().catch(err => {
    console.error(err);
    process.exit(1);
});
