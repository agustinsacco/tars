# UltraSignal Extension Implementation Plan

This document outlines the development plan for the `ultrahuman-signal` Gemini CLI extension.

## 1. Purpose

To allow users to easily retrieve health metrics from the Ultrahuman API directly through the Gemini CLI.

## 2. Architecture (Native Secrets)

The extension is an MCP server written in JavaScript. It uses the Tars Native Secrets Architecture.

- **Storage**: Secrets are managed by Tars in `~/.tars/.env`.
- **Access**: The extension accesses the `ULTRAHUMAN_API_KEY` via `process.env`.
- **Security**: No secrets are passed as tool arguments or stored in plain text by the extension itself.

## 3. Configuration

Users set the API key using the native command:
`tars secret set ULTRAHUMAN_API_KEY <your_key>`

## 4. API Interaction

- **Endpoint**: `https://partner.ultrahuman.com/api/v1/metrics`
- **Method**: `GET`
- **Headers**: `Authorization: <ULTRAHUMAN_API_KEY>`
- **Query Params**: `email`, `date` (YYYY-MM-DD)

## 5. Tools

### `get_metrics`

- **Description**: Fetches health metrics for a specific user and date.
- **Inputs**:
    - `email` (string): User email.
    - `date` (string): Date in YYYY-MM-DD format.
    - `metric` (string, optional): Filter for a specific data point (e.g., 'sleep').
    - `raw` (boolean, optional): Returns the full JSON response.
- **Logic**:
    1. Check for `process.env.ULTRAHUMAN_API_KEY`.
    2. If missing, return the standard Tars error message.
    3. Call the API using `axios`.
    4. Provide a summarized JSON view by default or the requested specific metric.
