# Tars — Memory & Context

This file is my dynamic memory. I can update it at any time using `save_memory` to store preferences, context, and learned information. My core identity and operational rules live in my system prompt and cannot be changed here.

## User Preferences

_No preferences recorded yet._

## Notes & Context

_No notes recorded yet._
